RETAIL SPARK / DATABRICKS PROJECT SOURCE DATA

Files:
1. sales.json       - 10,000 unique sales_id records
2. customer.json    - SCD Type 2 style source; multiple versions for some customers
3. product.json     - product master
4. store.json       - store master
5. promotion.json   - promotion master

Relationships:
sales.customer_id  -> customer.customer_id
sales.product_id   -> product.product_id
sales.store_id     -> store.store_id
sales.promotion_id -> promotion.promotion_id

Suggested pipeline:
BRONZE:
  raw_sales
  raw_customer
  raw_product
  raw_store
  raw_promotion

SILVER:
  clean_sales
  customer_scd2
  clean_product
  clean_store
  clean_promotion

GOLD:
  dim_date
  dim_customer
  dim_product
  dim_store
  dim_promotion
  fact_sales

SCD2:
customer_id is the business key.
Use effective_date/source_updated_at to create:
effective_from
effective_to
is_current

Important:
JSON files are JSON Lines (one JSON object per line), which is convenient for Databricks Auto Loader / Spark ingestion.

For a realistic project, next introduce:
- duplicate sales records
- late arriving sales
- invalid customer/product IDs
- null values
- malformed JSON records
- new customer versions
- new products/promotions
- incremental daily files
